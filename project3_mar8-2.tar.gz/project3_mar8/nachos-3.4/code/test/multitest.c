#include "syscall.h"

int main() {
  Exec("../test/multitest");
  Exit(0);
}
