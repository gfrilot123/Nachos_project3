#include "syscall.h"

int main() {
  
  Exit(0);
}
