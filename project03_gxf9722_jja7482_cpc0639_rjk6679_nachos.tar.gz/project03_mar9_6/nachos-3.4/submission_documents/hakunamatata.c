
#include "syscall.h"

int
main()
{
    Exec("../test/ItMeansNoWorries");
    Exit(0);
}
